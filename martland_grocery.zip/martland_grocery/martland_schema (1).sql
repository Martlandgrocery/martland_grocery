
-- Martland Grocery Hub SQL Schema
-- Compatible with MySQL 8.x / MariaDB 10.x
-- Run each statement in your SQL client (phpMyAdmin, Supabase SQL editor, etc.)

-- Drop tables if they exist (order matters because of FK constraints)
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS cart_items;
DROP TABLE IF EXISTS carts;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS addresses;
DROP TABLE IF EXISTS support_tickets;
DROP TABLE IF EXISTS franchise_applications;
DROP TABLE IF EXISTS app_downloads;
DROP TABLE IF EXISTS site_settings;
DROP TABLE IF EXISTS admin_users;
DROP TABLE IF EXISTS users;

-- Users (customers & staff)
CREATE TABLE users (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(120)          NOT NULL,
    email           VARCHAR(255) UNIQUE   NOT NULL,
    phone           VARCHAR(20),
    password_hash   VARCHAR(255)          NOT NULL,
    role            ENUM('customer','staff','vendor','franchisee') DEFAULT 'customer',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Addresses (one‑to‑many with users)
CREATE TABLE addresses (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED       NOT NULL,
    address_line1   VARCHAR(255)          NOT NULL,
    address_line2   VARCHAR(255),
    city            VARCHAR(100)          NOT NULL,
    state           VARCHAR(100)          NOT NULL,
    postal_code     VARCHAR(20)           NOT NULL,
    country         VARCHAR(80)           DEFAULT 'India',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Product categories
CREATE TABLE categories (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(120)          NOT NULL,
    slug            VARCHAR(140) UNIQUE   NOT NULL,
    description     TEXT,
    image_url       VARCHAR(255),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Products
CREATE TABLE products (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id     BIGINT UNSIGNED       NOT NULL,
    name            VARCHAR(160)          NOT NULL,
    slug            VARCHAR(180) UNIQUE   NOT NULL,
    description     TEXT,
    price           DECIMAL(10,2)         NOT NULL,
    stock_quantity  INT UNSIGNED          DEFAULT 0,
    image_url       VARCHAR(255),
    is_active       TINYINT(1)            DEFAULT 1,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Shopping carts (one open cart per user)
CREATE TABLE carts (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED       NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Cart items
CREATE TABLE cart_items (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    cart_id         BIGINT UNSIGNED       NOT NULL,
    product_id      BIGINT UNSIGNED       NOT NULL,
    quantity        INT UNSIGNED          NOT NULL DEFAULT 1,
    price_at_add    DECIMAL(10,2)         NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cart_id)    REFERENCES carts(id)    ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Orders
CREATE TABLE orders (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT UNSIGNED       NOT NULL,
    address_id      BIGINT UNSIGNED       NOT NULL,
    total_amount    DECIMAL(10,2)         NOT NULL,
    status          ENUM('pending','paid','shipped','completed','cancelled','refunded') DEFAULT 'pending',
    payment_method  ENUM('cod','razorpay','stripe','paypal') DEFAULT 'cod',
    placed_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)    REFERENCES users(id)      ON DELETE CASCADE,
    FOREIGN KEY (address_id) REFERENCES addresses(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Order items
CREATE TABLE order_items (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id        BIGINT UNSIGNED       NOT NULL,
    product_id      BIGINT UNSIGNED       NOT NULL,
    quantity        INT UNSIGNED          NOT NULL,
    unit_price      DECIMAL(10,2)         NOT NULL,
    FOREIGN KEY (order_id)  REFERENCES orders(id)   ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Admin users (for /admin dashboard)
CREATE TABLE admin_users (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(120) UNIQUE   NOT NULL,
    email           VARCHAR(255) UNIQUE   NOT NULL,
    password_hash   VARCHAR(255)          NOT NULL,
    role            ENUM('superadmin','manager','support') DEFAULT 'manager',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Franchise opportunity applications
CREATE TABLE franchise_applications (
    id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    applicant_name       VARCHAR(120)          NOT NULL,
    email                VARCHAR(255)          NOT NULL,
    phone                VARCHAR(20),
    city                 VARCHAR(100),
    state                VARCHAR(100),
    investment_capacity  VARCHAR(100),
    application_status   ENUM('new','review','approved','rejected') DEFAULT 'new',
    submitted_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Support / contact form tickets
CREATE TABLE support_tickets (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      BIGINT UNSIGNED NULL,
    name         VARCHAR(120) NOT NULL,
    email        VARCHAR(255) NOT NULL,
    subject      VARCHAR(180) NOT NULL,
    message      TEXT         NOT NULL,
    status       ENUM('open','in_progress','closed') DEFAULT 'open',
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Mobile app download stats
CREATE TABLE app_downloads (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id       BIGINT UNSIGNED NULL,
    platform      ENUM('android','ios') NOT NULL,
    version       VARCHAR(40)           NOT NULL,
    download_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- General site settings key/value
CREATE TABLE site_settings (
    id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `key` VARCHAR(120) UNIQUE NOT NULL,
    `value` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Example index for fast look‑ups
CREATE INDEX idx_products_category ON products(category_id);
